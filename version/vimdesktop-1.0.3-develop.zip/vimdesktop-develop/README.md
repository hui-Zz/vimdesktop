![icon](assets/images/vimdesktop_32.jpg) VimDesktop
===================================================

让所有 Windows 桌面程序拥有 Vim 操作风格的辅助工具

下载地址
--------
[VimDesktop 1.2.1](https://github.com/victorwoo/vimdesktop/archive/master.zip)

运行要求
--------
- [AutoHotkey](http://l.autohotkey.net/AutoHotkey_L_Install.exe)

快速起步
--------
TODO

已知问题
--------
TODO

下一步计划
----------
TODO

贡献及技术支持
--------------
官方 QQ 群: [271105729 （键盘控ViATc)](http://wp.qq.com/wpa/qunwpa?idkey=7aa346ef3d4d7700bc2dd398afe8168251d57f9ea7602479f28edc07f59ceb90)